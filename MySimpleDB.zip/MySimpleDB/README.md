# Extended SimpleDB 
##Date: April 19, 2015
### Updates 

 1. Code for handling new data types is completed and tested. Run '/MySimpleDB/src/simpledb/file/MyFileTester.java' to see output. 
 2. Code for advanced buffer handling  is completed. A trivial test cases is created. Run '/MySimpleDB/src/simpledb/buffer/MyBufferTester.java' to see output. 
 3. Check with TA and know how to simulate/test the 'buffer replacement' part.  
 
